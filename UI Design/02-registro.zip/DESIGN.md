---
name: PeriodistaIA
colors:
  surface: '#031427'
  surface-dim: '#031427'
  surface-bright: '#2a3a4f'
  surface-container-lowest: '#000f21'
  surface-container-low: '#0b1c30'
  surface-container: '#102034'
  surface-container-high: '#1b2b3f'
  surface-container-highest: '#26364a'
  on-surface: '#d3e4fe'
  on-surface-variant: '#c5c6cf'
  inverse-surface: '#d3e4fe'
  inverse-on-surface: '#213145'
  outline: '#8f9098'
  outline-variant: '#44474e'
  surface-tint: '#b7c6ee'
  primary: '#b7c6ee'
  on-primary: '#203050'
  primary-container: '#1b2b4b'
  on-primary-container: '#8393b8'
  inverse-primary: '#4f5e81'
  secondary: '#ffd65b'
  on-secondary: '#3d2f00'
  secondary-container: '#e7b900'
  on-secondary-container: '#5f4a00'
  tertiary: '#c6c6c7'
  on-tertiary: '#2f3131'
  tertiary-container: '#2a2c2c'
  on-tertiary-container: '#929393'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#b7c6ee'
  on-primary-fixed: '#091b3a'
  on-primary-fixed-variant: '#374668'
  secondary-fixed: '#ffe08b'
  secondary-fixed-dim: '#f0c110'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#584400'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#031427'
  on-background: '#d3e4fe'
  surface-variant: '#26364a'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 0.25rem
  sm: 0.5rem
  md: 1rem
  lg: 1.5rem
  xl: 2rem
  2xl: 3rem
  gutter: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 2.5rem
---

## Brand & Style

The design system is engineered for a journalistic AI copilot, balancing the traditional authority of newsrooms with the precision of modern artificial intelligence. The brand personality is **authoritative, analytical, and efficient**. It aims to evoke a sense of reliability and clarity for professionals navigating complex information.

The visual style is **Corporate Modern with Editorial influence**. It prioritizes high legibility and information density without sacrificing visual polish. The interface utilizes a structured grid and significant negative space to allow the user to focus on generated insights and editorial workflows.

## Colors

The palette is anchored by **Deep Navy (#1B2B4B)**, which serves as the primary background and structural color, providing a professional and focused environment. **Vibrant Yellow (#F5C518)** is used sparingly as an action and highlight color to draw attention to AI insights, primary calls to action, and critical alerts.

**Pure White (#FFFFFF)** is used for clean surface areas (cards, document editors) to ensure maximum readability for long-form content. Text on these light surfaces utilizes the Deep Navy for high-contrast legibility, while text on dark backgrounds utilizes White and Yellow to maintain hierarchy.

## Typography

This design system relies exclusively on **Inter** to deliver a systematic and utilitarian feel. The hierarchy is strictly enforced through weight and scale. 

- **Display & Headlines:** Use tighter letter spacing and SemiBold/Bold weights to mimic editorial titles.
- **Body Text:** Optimized for long-form reading with generous line-height (1.5x) to prevent eye strain during research and drafting.
- **Labels:** Set in Medium or SemiBold with slight tracking for clear categorization and metadata display.

## Layout & Spacing

The design system employs a **12-column fluid grid** for desktop and a **4-column grid** for mobile. 

The spacing rhythm is based on a **4px baseline**, ensuring all components align perfectly. Layouts should utilize "Surface" containers to separate the AI sidebar from the primary editorial workspace. Use `lg` (24px) padding for primary content blocks and `md` (16px) for internal component spacing. Vertical rhythm is critical; maintain consistent `2xl` (48px) spacing between major sections to preserve an airy, editorial feel.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows**. 

1. **Base Layer:** Deep Navy (#1B2B4B) background.
2. **Surface Layer:** White (#FFFFFF) or slightly desaturated Navy for containers, providing a distinct "sheet" metaphor for documents.
3. **Shadows:** Use extra-diffused, low-opacity shadows (`0px 4px 20px rgba(0,0,0,0.08)`) on white surfaces to indicate interactivity. On dark backgrounds, use subtle 1px inner borders (10% opacity white) instead of shadows to define edges.
4. **Interactive States:** Lifted elements (hover) should slightly increase shadow spread or change border-color to the Accent Yellow.

## Shapes

The shape language is **Refined and Modern**. All primary containers, cards, and input fields use a consistent **12px (rounded-xl)** radius. 

Buttons and tags follow this logic to feel integrated within the editorial layout. Smaller utility elements like checkboxes use the `soft` (4px) setting to maintain a professional, sharp-aligned aesthetic.

## Components

- **Buttons:** Primary buttons are Solid Accent Yellow with Navy text for high visibility. Secondary buttons use a Navy outline or a ghost style with White/Navy text depending on the background surface.
- **Input Fields:** Large, 12px rounded fields with a 1px border. On White surfaces, use a light grey border; on Navy backgrounds, use a semi-transparent white border.
- **AI Insight Cards:** These should have a subtle Yellow left-border accent (4px) to distinguish AI-generated content from manual user input.
- **Chips/Tags:** Used for categorization and SEO keywords. Small 12px radius, light-grey background on White, or Navy-tinted background on Dark.
- **Editorial Workspace:** A pure White central canvas with minimal distractions, utilizing the `body-lg` typography for drafting.
- **Navigation:** A collapsed sidebar or top-bar in solid Deep Navy to maximize the active workspace area.